import React from 'react'

export default function Articles() {
  return (
    <div>Articles</div>
  )
}
