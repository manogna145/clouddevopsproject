import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { Card, Avatar, Typography, Box, Divider, Grid, IconButton } from "@mui/material";
import FacebookIcon from '@mui/icons-material/Facebook';
import TwitterIcon from '@mui/icons-material/Twitter';
import InstagramIcon from '@mui/icons-material/Instagram';

export default function UserProfile() {
  const [user, setUser] = useState({
    fullname: "",
    username: "",
    password: "",
    gender: "",
    age: "",
    email: "",
    phone: "N/A",
    socialLinks: {
      facebook: "#",
      twitter: "#",
      instagram: "#"
    }
  });
  
  const [showPassword, setShowPassword] = useState(false);

  const getdata = async () => {
    const user = localStorage.getItem('user');
    
   
  
    try {
      const response = await axios.get(`http://localhost:8080/user/getuserdata/${user}`);
      setUser(response.data);
    } catch (error) {
      console.log("Something went wrong", error);
    }
    console.log(user)
  };
  

  useEffect(() => {
    getdata();
  }, []);

  return (
    <Box sx={{ display: "flex", justifyContent: "center", alignItems: "center", minHeight: "100vh", padding: 2 }}>
      <Card sx={{ display: "flex", width: "80%", maxWidth: 700, boxShadow: 3 }}>
        <Box sx={{
          background: "linear-gradient(to right, #f46b45, #eea849)",
          color: "white",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          padding: 3,
          width: "35%",
          borderRadius: "10px 0 0 10px"
        }}>
          <Avatar src={user.avatar} alt={user.fullname} sx={{ width: 100, height: 100, mb: 2 }} />
          <Typography variant="h6" sx={{ fontWeight: "bold" }}>{user.fullname}</Typography>
          <Typography>{user.role || "N/A"}</Typography>
        </Box>

        {/* Right Side - Details */}
        <Box sx={{ flex: 1, padding: 3 }}>
          <Typography variant="h6" sx={{ fontWeight: "bold", mb: 1 }}>Information</Typography>
          <Divider />
          
          <Grid container spacing={2} sx={{ mt: 1 }}>
            <Grid item xs={6}>
              <Typography variant="body2" sx={{ fontWeight: "bold" }}>Username</Typography>
              <Typography color="text.secondary">{user.username}</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="body2" sx={{ fontWeight: "bold" }}>Gender</Typography>
              <Typography color="text.secondary">{user.gender}</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="body2" sx={{ fontWeight: "bold" }}>Age</Typography>
              <Typography color="text.secondary">{user.age}</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="body2" sx={{ fontWeight: "bold" }}>Email</Typography>
              <Typography color="text.secondary">{user.email}</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="body2" sx={{ fontWeight: "bold" }}>Phone</Typography>
              <Typography color="text.secondary">{user.phone}</Typography>
            </Grid>
            <Grid item xs={6}>
              <Typography variant="body2" sx={{ fontWeight: "bold" }}>Password</Typography>
              <Typography color="text.secondary">
                {showPassword ? user.password : "•".repeat(user.password.length)}
                <IconButton
                  onClick={() => setShowPassword(!showPassword)}
                  size="small"
                  sx={{ marginLeft: "10px" }}
                >
                  {showPassword ? "Hide" : "Show"}
                </IconButton>
              </Typography>
            </Grid>
          </Grid>

          {/* Social Links */}
          <Box sx={{ display: "flex", mt: 3 }}>
            <a href={user.socialLinks?.facebook || "#"} style={{ color: "#3b5998", marginRight: "10px" }}>
              <FacebookIcon />
            </a>
            <a href={user.socialLinks?.twitter || "#"} style={{ color: "#00acee", marginRight: "10px" }}>
              <TwitterIcon />
            </a>
            <a href={user.socialLinks?.instagram || "#"} style={{ color: "#C13584" }}>
              <InstagramIcon />
            </a>
          </Box>
        </Box>
      </Card>
    </Box>
  );
}
