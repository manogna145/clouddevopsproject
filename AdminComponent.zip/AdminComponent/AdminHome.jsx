import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { PlusCircle, Edit, Trash, Users, Eye } from 'lucide-react';

const AdminHome = () => {
  const [stats, setStats] = useState({
    totalFoodItems: 150,
    totalUsers: 1200,
  });

  return (
    <div style={{ display: 'flex', height: '100vh' }}>
      {/* Sidebar */}
      <div style={{ backgroundColor: '#333', color: '#fff', width: '250px', padding: '20px' }}>
        <div style={{ textAlign: 'center', marginBottom: '20px' }}>
          <h2>Admin Dashboard</h2>
        </div>
        <nav style={{ listStyle: 'none', padding: 0 }}>
          <ul>
            <li style={{ marginBottom: '10px' }}>
              <Link to="/add-food" style={{ display: 'flex', alignItems: 'center', color: '#fff', textDecoration: 'none', padding: '10px', borderRadius: '5px' }}>
                <PlusCircle size={20} /> Add Food
              </Link>
            </li>
            {/* ... other navigation items with similar inline styles */}
          </ul>
        </nav>
      </div>

      {/* Dashboard Content */}
      <div style={{ flex: 1, padding: '20px' }}>
        <h1 style={{ marginBottom: '20px' }}>Welcome to Admin Dashboard</h1>

        {/* Quick Stats */}
        <div style={{ display: 'flex', justifyContent: 'space-between' }}>
          <div style={{ backgroundColor: '#f0f0f0', padding: '20px', borderRadius: '5px', boxShadow: '0 2px 5px rgba(0, 0, 0, 0.1)' }}>
            <h3>Total Food Items</h3>
            <p>{stats.totalFoodItems}</p>
          </div>
          {/* ... other stat with similar inline styles */}
        </div>

        {/* Recent Activities or Notifications */}
        <div style={{ marginTop: '20px' }}>
          <h3>Recent Activities</h3>
          <ul style={{ listStyle: 'none', padding: 0 }}>
            <li style={{ marginBottom: '10px' }}>
              <strong>Added a new food item</strong>: Apple - 2 hours ago
            </li>
            {/* ... other recent activities with similar inline styles */}
          </ul>
        </div>
      </div>
    </div>
  );
};

export default AdminHome;