import React from 'react'

export default function AdminProfile() {
  return (
    <div>AdminProfile</div>
  )
}
