package com.klef.jfsd.sdp.model;

public class ExerciseInput {
	
	private int eid;
	private int uid;
	private int numberofmin;
	private String exerciseType;
	public int getEid() {
		return eid;
	}
	public void setEid(int eid) {
		this.eid = eid;
	}
	public int getUid() {
		return uid;
	}
	public void setUid(int uid) {
		this.uid = uid;
	}
	public int getNumberofmin() {
		return numberofmin;
	}
	public void setNumberofmin(int numberofmin) {
		this.numberofmin = numberofmin;
	}
	public String getExerciseType() {
		return exerciseType;
	}
	public void setExerciseType(String exerciseType) {
		this.exerciseType = exerciseType;
	}

}
