package com.klef.jfsd.sdp.model;

public class UserExerciseRetrieval {
	
	
	private String exerciseType;
	private int calorieBurn;
	private int numberofmin;
	public String getExerciseType() {
		return exerciseType;
	}
	public void setExerciseType(String exerciseType) {
		this.exerciseType = exerciseType;
	}
	public int getCalorieBurn() {
		return calorieBurn;
	}
	public void setCalorieBurn(int calorieBurn) {
		this.calorieBurn = calorieBurn;
	}
	public int getNumberofmin() {
		return numberofmin;
	}
	public void setNumberofmin(int numberofmin) {
		this.numberofmin = numberofmin;
	}

}
